﻿using System.Collections.Generic;
using SUS.HTTP;
using SUS.MvcFramework;

namespace BattleCards
{
    public class Startup:IMvcApplication
    {
        public void ConfigureServices(IServiceCollection serviceCollection)
        {
            throw new System.NotImplementedException();
        }

        public void Configure(List<Route> routeTable)
        {
            throw new System.NotImplementedException();
        }
    }
}