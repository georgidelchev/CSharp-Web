﻿using System.Collections.Generic;
using SUS.HTTP;
using SUS.MvcFramework;

namespace MishMashWebApp
{
    public class StartUp : IMvcApplication
    {
        public void ConfigureServices(IServiceCollection serviceCollection)
        {
        }

        public void Configure(List<Route> routeTable)
        {
        }
    }
}
